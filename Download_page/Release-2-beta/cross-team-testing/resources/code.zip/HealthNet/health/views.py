"""
Authors: Nahjee Sowah, Andrew Fountain, Chris Cassidy, Chris Cifolelli, Bryan Quinn
"""
import os

from django.contrib import auth
from django.contrib.auth.decorators import *
from django.contrib.auth.models import Group
from django.shortcuts import *
from django.template.context_processors import csrf
from django.views.decorators.http import require_http_methods
from .forms import *
from .models import *


def home_page(request):
    """
    Brings user to website home
    :param request: user input
    :return: renders homepage
    """
    return render(request, 'health/index.html')


def patient_registration(request):
    """
    Brings user to registration page and
    once entered brings user to success or deny page
    :param request: user input
    :return: page depending on input
    """
    if request.method == "POST":
        form = PatientRegistrationForm(request.POST, request.FILES)
        if form.is_valid():
            patient = form.save(commit=False)
            if User.objects.filter(email=patient.email).exists():
                return render(request, 'health/invalid_email.html')
            else:
                patient.username = patient.email
                patient.set_password(patient.password)
                patient.save()
                if not Group.objects.filter(name="Patient").exists():
                    Group.objects.create(name="Patient")
                patient_group = Group.objects.get(name="Patient")
                patient_group.user_set.add(patient)
                hospital = Hospital.objects.get(id=request.POST.get('main_hospital'))
                hospital.number_patients += 1
                hospital.save()
                log_activity(action='Patient Registered', request=request)
                return render(request, 'health/registration_success.html', {'message': "Registered as a Patient"})
        else:
            return render(request, 'health/error_template.html',
                          {'message': "There were errors in your registration form: ", 'errors': form.errors})
    else:
        form = PatientRegistrationForm()
        return render(request, 'health/register.html', {'form': form, 'title': "New Patient",
                                                        'submit': "Register", 'cancel': "Return to Login"})


def login(request):
    """
    Brings user to login page, but if user is logged in brings them to calender
    :param request: user request
    :return: login page or calender
    """
    if request.user.is_authenticated():
        if Nurse.objects.filter(id=request.user.id).exists():
            request.user.isNurse = 1
        if Doctor.objects.filter(id=request.user.id).exists():
            request.user.isDoctor = 1
        return calendar(request)
    dictionary = {}
    dictionary.update(csrf(request))
    return render_to_response("health/login.html", dictionary)


@require_http_methods(["POST"])
def auth_view(request):
    """
    Sees if the the user name and passwords are correct
    :param request: user request
    :return: the login page
    """
    username = request.POST.get('username', '')  # if no value found in dictionary, return empty string
    password = request.POST.get('password', '')
    user = auth.authenticate(username=username, password=password)

    if user is not None:
        auth.login(request, user)
        return loggedin(request)
    else:
        return invalid_login(request)


def loggedin(request):
    """
    Logs user in
    :param request: user input
    :return: logged in page
    """
    return render_to_response('health/loggedin.html',
                              {'full_name': request.user.first_name + " " + request.user.last_name})


@require_http_methods(["POST"])
def invalid_login(request):
    """
    Brings user to invalid log in page
    :param request: user input
    :return: invalid login page
    """
    return render_to_response('health/invalid_login.html')


def logout(request):
    """
    Brings user to logout page
    :param request: user input
    :return: logout page
    """
    auth.logout(request)
    return render_to_response('health/logout.html')


@login_required
def view_tests(request):
    test_list = []

    if is_patient(request):
        for test in Test.objects.filter(patient=request.user.id):
            if test.is_released:
                test_list.append(test)
    elif is_doc(request):
        test_list = Test.objects.all()

    context = {
        'isLoggedIn': request.user.is_authenticated,
        'test_list': test_list,
    }

    return render(request, 'health/view_tests.html', context)


@login_required
def create_test(request):
    if request.user.is_authenticated and is_doc(request):
        if request.method == "POST":
            form = CreateTestForm(request.POST, request.FILES)
            if form.is_valid():
                test = form.save(commit=False)
                patient = get_object_or_404(Patient, id=request.POST.get('patient'))
                log_activity('Test created for ' + str(patient.username) + ' by Dr. ' +
                             str(request.user.last_name) + ' called ' +
                             str(request.POST.get('description')), request)
                test.issuer = Doctor.objects.get(id=request.user.id)
                form.save()
                return render_to_response('health/registration_success.html', {'message': "Created a Test"})
            else:
                errors = form.errors
                return render(request, 'health/error_template.html', {
                    'message': 'There were errors in your appointment form: ', 'errors': errors})
        else:
            form = CreateTestForm()
            return render(request, 'health/register.html', {'form': form, 'title': "New Test",
                                                            'submit': "Create", 'cancel': "Cancel"})


@login_required
def manage_tests(request):

    if is_doc(request):
        test_list = Test.objects.filter(issuer=Doctor.objects.get(id=request.user.id))
    else:
        test_list = []

    context = {
        'isLoggedIn': request.user.is_authenticated,
        'test_list': test_list,
    }
    print(test_list)
    print(is_doc(request))
    return render(request, 'health/manage_tests.html', context)


@login_required
def create_appointment(request):
    """
    Decides whether an appointment is valid
    :param request: user input
    :return: confirmation
    """
    if request.method == "POST":
        form = None
        try:
            if Patient.objects.filter(id=request.user.id):
                form = PatientAppointment(request.POST)
                appointment = form.save(commit=False)
                appointment.patient = Patient.objects.filter(id=request.user.id)[0]
            elif Doctor.objects.filter(id=request.user.id):
                form = DoctorAppointment(request.POST)
                form.doctor = request.user.id
                appointment = form.save(commit=False)
                appointment.doctor = Doctor.objects.filter(id=request.user.id)[0]
            else:
                form = NurseAppointment(request.POST)
                appointment = form.save(commit=False)
            if form.is_valid():
                appointment.save()
                log_activity('Appointment created for ' + str(appointment.start_date)[:19] + ' with Dr. ' +
                             str(appointment.doctor.last_name) + ' ' + ' at ' +
                             str(appointment.hospital), request)
                return render_to_response('health/appt_created.html')
            else:
                return render(request, 'health/appt_invalid.html', {'form': form})
        except ValueError:
            if form:
                errors = form.errors
            else:
                errors = "Unknown error"
            return render(request, 'health/error_template.html',
                          {'message': 'There were errors in your appointment form: ', 'errors': errors})
    else:
        if Patient.objects.filter(id=request.user.id):
            form = PatientAppointment()
        elif Doctor.objects.filter(id=request.user.id):
            form = DoctorAppointment()
            form.doctor = request.user.id
        else:
            form = NurseAppointment()
        return render(request, 'health/create_appointment.html', {'form': form})


@login_required
def update_appointment(request, pk):
    """
    view for updating appointments
    :param request: web request, possibly containing POST information
    :param pk: primary key for the given appointment
    :return: web page render
    """
    appointment = get_object_or_404(Appointment, id=pk)  # you could just do a get_object_or_404(Appointment, id=pk)
    if request.method == "POST":
        if Patient.objects.filter(id=request.user.id):
            form = PatientAppointment(request.POST, instance=appointment)
            form.patient = request.user.id
        elif Doctor.objects.filter(id=request.user.id):
            form = DoctorAppointment(request.POST, instance=appointment)
            form.doctor = request.user.id
        else:
            form = NurseAppointment(request.POST, instance=appointment)

        if form.is_valid():
            if 'update' in request.POST:
                save_appointment = form.save(commit=False)
                save_appointment.save()
                log_activity('Appointment updated to ' + str(appointment.start_date)[:19] + ' with Dr. ' +
                             str(appointment.doctor.last_name) + ' ' + ' at ' +
                             str(appointment.hospital), request)
                return render(request, 'health/appt_updated.html')
            else:
                log_activity('Appointment deleted for ' + str(appointment.start_date)[:19] + ' with Dr. ' +
                             str(appointment.doctor.last_name) + ' ' + ' at ' +
                             str(appointment.hospital), request)
                appointment.delete()
                return render(request, 'health/delete_appointment.html')
        else:
            return render(request, 'health/error_template.html',
                          {'message': 'There were errors in your appointment form: ', 'errors': form.errors})
    else:
        if Patient.objects.filter(id=request.user.id):
            form = PatientAppointment(instance=appointment)

        elif Doctor.objects.filter(id=request.user.id):
            form = DoctorAppointment(instance=appointment)
        else:
            form = NurseAppointment(instance=appointment)
        return render(request, 'health/appt_update.html', {'form': form})


@login_required
def delete_appointment(request, appointment_id):
    """
    delete appointment
    :param request: user input
    :param appointment_id: what appointment it is
    :return: the calender page
    """
    a = get_object_or_404(Appointment, pk=appointment_id)
    a.delete()
    return render_to_response('health/delete_appointment.html')


@login_required
def calendar(request):
    """
    Builds calender page for specific user
    :param request: user input
    :return: calender
    """
    #  template = loader.get_template('health/calendar.html')

    if request.user.is_authenticated:
        if_nurse = True if Nurse.objects.filter(id=request.user.id) else False
        appointment_list = Appointment.objects.filter(patient=request.user.id)

        context = {
            'isLoggedIn': request.user.is_authenticated,
            'isNurse': if_nurse,
            'appointment_list': appointment_list,
        }

        return render(request, 'health/calendar.html', context)
    else:
        return redirect('health/index.html')


def error_page(request):
    """
    brings up error 404 page if error
    :param request: user input
    :return: 404 page
    """
    return render_to_response('health/notFound.html')


def update_patient_profile(request):
    """
    Brings user to update patient profile page
    :param request: user input
    :return: update profile page
    """
    patient = get_object_or_404(Patient, id=request.user.id)
    if request.method == "POST":
        form = PatientUpdateForm(data=request.POST, instance=patient)
        if form.is_valid():
            save_patient = form.save(commit=False)
            save_patient.save()
            log_activity(action='Profile information updated', request=request)
            return render(request, 'health/profile_updated.html')
        else:
            return render(request, 'health/error_template.html',
                          {'message': "There were errors in your update form: ", 'errors': form.errors})
    else:
        form = PatientUpdateForm(instance=patient)
        return render(request, 'health/profile_update.html', {'form': form})


def update_med_info(request, patient_id):
    """
    Allows patient to upload a new file for medical info
    :param request: user input
    :param patient_id: user id
    :return: update medical info page
    """
    patient = get_object_or_404(Patient, id=patient_id)
    if request.method == 'POST':
        form = UpdateMedForm(data=request.POST, files=request.FILES, instance=patient)
        if form.is_valid():
            (form.save(commit=False)).save()
        #    patient.medical_information = str(patient.username) + "medical information"
            log_activity(action='Patient medical information updated', request=request)
            return render(request, 'health/med_updated.html')  # Will change
        else:
            return render(request, 'health/error_template.html',
                          {'message': "There were errors in your form:", 'errors': form.errors})
    else:
        form = UpdateMedForm(instance=patient)
        return render(request, 'health/update_med.html', {'form': form})


def log_activity(action, request):
    """
    writes activity log for a user. form and new are for recording patient registration.
    This function wont work if multiple people go to log their activity at the exact same time
    :param action: Users input
    :param request: activity to log
    :return: none
    """
    # writes activity log for a user. form and new are for recording patient registration.
    # This function wont work if multiple people go to log their activity at the exact same time

    # all this jazz before the while loop determines which files to write to and with what information
    file_list = []  # stores log text file names
    if request.user.is_authenticated():  # if user is logged in
        if Patient.objects.filter(
                username=request.user.username).exists():  # if/elif statements check if user is either
            # a doctor, nurse, patient, or admin
            patient = get_object_or_404(Patient, username=request.user.username)
            actor = 'Patient'
            file_list.append(
                'logs/hospitals/' + str(patient.main_hospital.hospital_name).replace(' ',
                                                                                     '_') + '_' + 'activity_log.txt')
            file_list.append(
                'logs/patients/' + str(patient.username) + '_' + 'activity_log.txt')  # adds file name to list

        elif Nurse.objects.filter(username=request.user.username).exists():
            user = get_object_or_404(Nurse, username=request.user.username)
            actor = 'Nurse'
            file_list.append('logs/hospitals/' + str(user.working_hospital.hospital_name).replace(' ',
                                                                                                  '_') + '_' + 'activity_log.txt')
            file_list.append('logs/nurses/' + str(user.username) + '_' + 'activity_log.txt')

        elif Doctor.objects.filter(username=request.user.username).exists():
            user = get_object_or_404(Doctor, username=request.user.username)
            actor = 'Doctor'
            for hospital in user.hospitals.all(): # writes action to activity log of all hospitals the doctor works at
                file_list.append(
                    'logs/hospitals/' + str(hospital.hospital_name).replace(' ', '_') + "activity_log.txt")
            file_list.append('logs/doctors/' + str(user.username) + '_' + 'activity_log.txt')

        else:
            user = request.user  # for admins, they have no extra data stored in models
            actor = 'Admin'
            # hospital_name = get_object_or_404(Hospital, id=2)
            #  TODO: Change this to an actual hospital. Should admin actions be logged in a hospital?
            # that the admin might be assigned to.
            # Are admins supposed to be assigned to hospitals?
            file_list.append('logs/admins/' + str(user.username) + '_' + 'activity_log.txt')

        username = request.user.username

    else:  # only for when patient is registering
        username = request.POST.get('email')
        file_list.append('logs/patients/' + str(username) + '_' + 'activity_log.txt')

        hospital_name = get_object_or_404(Hospital, id=request.POST.get('main_hospital')).hospital_name
        file_list.append('logs/hospitals/' + str(hospital_name).replace(' ', '_') + '_' + 'activity_log.txt')
        actor = 'Patient'

    i = 0
    while i < len(file_list):  # writes log in each file whose name is specified in file_list
        file = open(file_list[i], 'a')
        file.write(str(timezone.now())[:19])
        # appends truncated date. We don't need fractions of a second or time offset to be recorded, times in UTC
        file.write('{0:<80}'.format('\t\t' + actor + '\tusername:\t' + str(username)))  # purty even spacing
        file.write('\t\tAction: ' + action + '\n')
        file.close()
        i += 1


# this function is mostly redundant. Would return all logs for given username
def view_log_activity(request, username='arf8856@rit.edu',
                      hospital=None):  # can view either hospital log or user log, not both
    if request.user.is_staff:  # can only view log activity as an admin (staff)
        if username is not None:
            if Patient.objects.filter(username=username).exists():
                file = open('logs/patients/' + str(username) + '_' + 'activity_log.txt', 'r')
                return HttpResponse(content=file,
                                    content_type='text/plain')  # returns contents of text file as http response
            else:  # todo: change HttpResponses to template renders
                return HttpResponse('Patient not found!')
    else:
        render_to_response('health/notFound.html')


def sdi(time='2016-01-01 00:00:00'):
    # string date to integer function, for converting string times as found in function below.
    # returns time in seconds since 2000
    # substring for each part of the date given
    year = int(time[2:4])
    month = int(time[5:7])
    day = int(time[8:10])
    hour = int(time[11:13])
    minute = int(time[14:16])
    sec = int(time[17:19])

    def month_dict(m, y):  # returns number of seconds in each month
        if (y % 4) == 0 and y != 0:  # leap years don't happen on the turn of a century
            return {  # returns number of seconds in each month if a leap year. 86400 is number of seconds per day
                1: (31 * 86400), 2: (29 * 86400), 3: (31 * 86400), 4: (30 * 86400), 5: (31 * 86400),
                6: (30 * 86400),
                7: (31 * 86400), 8: (31 * 86400), 9: (30 * 86400), 10: (31 * 86400), 11: (30 * 86400),
                12: (31 * 86400)
            }.get(m, 30)

        else:
            return {
                # returns number of seconds in each month if not a leap year. 86400 is number of seconds per day
                1: (31 * 86400), 2: (28 * 86400), 3: (31 * 86400), 4: (30 * 86400), 5: (31 * 86400),
                6: (30 * 86400),
                7: (31 * 86400), 8: (31 * 86400), 9: (30 * 86400), 10: (31 * 86400), 11: (30 * 86400),
                12: (31 * 86400)
            }.get(m, 30)  # end month_dict

    def s_in_year(y):
        if (y % 4) == 0:
            return 31622400  # number of seconds in a leap year
        else:
            return 31536000  # number of seconds in a normal year

    year_sum = 0
    k = 0
    while k < year:  # doesnt include current year. Not that it matters, really
        year_sum += s_in_year(k)
        k += 1

    j = 0
    month_sum = 0
    while j < month:
        month_sum += month_dict(j + 1, year)
        j += 1
    # returns number of seconds that the time is from midnight 1/1/2000
    return year_sum + month_sum + day * 24 + hour * 3600 + minute * 60 + sec


def view_log_by_time(request):
    # can either search by username or by hospital, not both
    #   time is taken as a string, time 1 being starting date/time
    #   and time 2 being end date/time. In same format as str(django's timezone.now output)
    # some default values to get rid of annoying yellow highlighting by pycharm
    # only hospital and username defaults are used
    hospital = None
    username = ''
    time1 = '2000-01-01 00:00:00'
    time2 = '2099-12-12 23:59:59'

    if request.user.is_staff == 0:  # can only access if admin
        return render_to_response('health/notFound.html')

    open("logs/temp.txt", 'w').close()  # clears temp text file

    if request.method == "GET":  # form to choose user/hospital data
        form = LogSearchForm()
        return render(request, 'health/log_search.html', {'form': form})
    if request.method == "POST":
        form = LogSearchForm(request.POST)
        if form.is_valid():
            username = str(request.POST.get('user_email'))
            time1 = request.POST.get('start_time')
            time2 = request.POST.get('end_time')
        else:
            return render(request, 'health/error_template.html',
                          {'message': "There were errors in your log search form: ", 'errors': form.errors})

    if request.POST.get('hospital') != '':
        hospital = get_object_or_404(Hospital, id=int(request.POST.get('hospital')))
    if username == '' and hospital is None:
        return render(request, 'health/error_template.html', {'message':"Please specify either a hospital or a user"})
    file = False
    if username != '' and request.user.is_staff:  # only admins can do this
        # if/elif statements check if user is either a doctor, nurse, patient, or admin
        if Patient.objects.filter(username=username).exists():
            file = open('logs/patients/' + str(username) + '_' + 'activity_log.txt', 'r')  # log text file to be read

        elif Nurse.objects.filter(username=username).exists():
            file = open('logs/nurses/' + str(username) + '_' + 'activity_log.txt', 'r')

        elif Doctor.objects.filter(username=username).exists():
            file = open('logs/doctors/' + str(username) + '_' + 'activity_log.txt', 'r')
        else:
            return render(request, 'health/error_template.html', {'message': "Invalid user provided"})

    elif hospital is not None:
        file = open('logs/hospitals/' + str(hospital.hospital_name).replace(' ', '_') + '_' + 'activity_log.txt', 'r')

    temp_file = open("logs/temp.txt", 'a')
    line_list = file.readlines()
    # creates a list whose elements are each line from the log text file
    s_time1 = sdi(time1)  # time 1 and 2 in seconds since midnight 1/1/2000
    s_time2 = sdi(time2)

    i = 0
    while i < len(line_list):
        if sdi(str(line_list[i])[0:19]) >= s_time1 and sdi(
                str(line_list[i])[0:19]) <= s_time2:  # compares each log entry time to bounds passed to function
            temp_file.write(str(line_list[i]))
        i += 1
    temp_file = open("logs/temp.txt", 'r')
    return HttpResponse(content=temp_file, content_type='text/plain')  # works for now. a bit ugly, though
    # return_file = temp_file.readlines()   #templates are evil; doesnt render tab characters from text file correctly
    # return render(request, 'health/view_log.html', {'return_file': return_file})


def view_patients(request):
    """
    Allows doctors and nurses to be able to view patients
    :param request: user input
    :return: patient list page
    """
    if request.user.is_authenticated():
        template = loader.get_template('health/patients.html')

        patient_list = []

        if Doctor.objects.filter(id=request.user.id).exists():
            # User is a Doctor
            this_user = get_object_or_404(Doctor, id=request.user.id)
            for patient in Patient.objects.all():
                if patient.is_checked_in:
                    if this_user.hospitals.filter(pk=patient.current_hospital_id).exists():
                        patient_list.append(patient)

        elif Nurse.objects.filter(id=request.user.id).exists():
            # User is a Nurse
            this_user = get_object_or_404(Nurse, id=request.user.id)
            hospital = this_user.working_hospital
            patient_list = Patient.objects.filter(current_hospital_id=hospital.id)

        elif not Patient.objects.filter(id=request.user.id).exists():
            # User is an admin
            patient_list = Patient.objects.all()

        context = {
            'patients': patient_list,
             }

        return HttpResponse(template.render(context, request))
    else:
        return render(request, 'health/notFound.html')


def admin_genesis(request):
    """

    :param request: user input
    :return:
    """
    if request.user.is_staff:
        if request.method == "POST":
            form = AdminCreationForm(request.POST)
            if form.is_valid():
                if User.objects.filter(email=request.POST.get('email')).exists():
                    return render(request, 'health/invalid_email.html')
                else:
                    username = request.POST.get('email')
                    password = request.POST.get('password')
                    User.objects.create_superuser(username, username, password)
                    log_activity(action='Admin Created', request=request)
                    return render(request, 'health/registration_success.html', {'message': "Created an Admin"})
            else:
                return render(request, 'health/error_template.html',
                              {'message': "There were errors in your admin creation form: ", 'errors': form.errors})
        else:
            form = AdminCreationForm()
            return render(request, 'health/register.html', {'form': form, 'title': "New Admin",
                                                            'submit': "Create", 'cancel': "Cancel"})
    else:
        return render_to_response('health/notFound.html')


def doctor_creation(request):
    """
    Allows administrator create a doctor
    :param request: user input
    :return: new doctor
    """
    if request.user.is_staff:  # can only create doctors if admin (staff)
        if request.method == "POST":
            form = DoctorCreationForm(request.POST)
            if form.is_valid():
                doctor = form.save(commit=False)
                if User.objects.filter(email=doctor.email).exists():
                    return render(request, 'health/invalid_email.html')
                else:
                    doctor.username = doctor.email
                    doctor.set_password(doctor.password)
                    doctor.save()
                    if not Group.objects.filter(name="Doctor").exists():
                        Group.objects.create(name="Doctor")
                    doc_group = Group.objects.get(name="Doctor")
                    doc_group.user_set.add(doctor)
                    log_activity(action='Doctor Registered: ' + str(doctor.email), request=request)
                    return render(request, 'health/error_template.html', {'message': "Doctor created"})
            else:
                return render(request, 'health/error_template.html',
                              {'message': "There were errors in your doctor creation form: ", 'errors': form.errors})
        else:
            form = DoctorCreationForm()
            return render(request, 'health/register.html', {'form': form, 'title': "New Doctor",
                                                            'submit': "Create", 'cancel': "Cancel"})
    else:
        return render_to_response('health/notFound.html')


def nurse_creation(request):
    """
    Allows administrator to create a new nurse.
    :param request: user input
    :return: new nurse
    """
    if request.user.is_staff:  # can only create nurses if admin (staff)
        if request.method == "POST":
            form = NurseCreationForm(request.POST)
            if form.is_valid():
                nurse = form.save(commit=False)
                if User.objects.filter(email=nurse.email).exists():
                    return render(request, 'health/invalid_email.html')
                else:
                    nurse.username = nurse.email
                    nurse.set_password(nurse.password)
                    nurse.save()
                    if not Group.objects.filter(name="Nurse").exists():
                        Group.objects.create(name="Nurse")
                    nurse_group = Group.objects.get(name="Nurse")
                    nurse_group.user_set.add(nurse)
                    log_activity(action='Nurse Registered: ' + str(nurse.email), request=request)
                    return render(request, 'health/registration_success.html', {'message': "Created an Nurse"})
            else:
                return render(request, 'health/error_template.html',
                              {'message': "There were errors in your nurse creation form: ", 'errors': form.errors})
        else:
            form = NurseCreationForm()
            return render(request, 'health/register.html', {'form': form, 'title': "New Nurse",
                                                            'submit': "Create", 'cancel': "Cancel"})
    else:
        return render_to_response('health/notFound.html')


def hospital_creation(request):
    """
    Allows administrator to create a new nurse.
    :param request: user input
    :return: new nurse
    """
    if request.user.is_staff:  # can only create hospitals if admin (staff)
        if request.method == "POST":
            form = HospitalCreationForm(request.POST)
            if form.is_valid():
                hospital = form.save(commit=False)
                if Hospital.objects.filter(hospital_name=hospital.hospital_name).exists():
                    return render(request, 'health/invalid_email.html')
                else:
                    hospital.save()
                    log_activity(action='Hospital Created: ' + str(hospital.hospital_name), request=request)
                    return render(request, 'health/registration_success.html')
            else:
                return render(request, 'health/error_template.html',
                              {'message': "There were errors in your nurse creation form: ", 'errors': form.errors})
        else:
            form = HospitalCreationForm()
            return render(request, 'health/register.html', {'form': form, 'title': "New Hospital",
                                                            'submit': "Create", 'cancel': "Cancel"})
    else:
        return render_to_response('health/notFound.html')


def private_messaging(request):
    """
    allows users to send private messages between each other.
    :param request: user input
    :return: message to user
    """
    if request.user.is_authenticated():
        if request.method == "POST":
            form = MessageForm(request.POST)
            if form.is_valid():
                if User.objects.filter(email=request.POST.get('recipient')).exists():
                    if not os.path.exists('messages/' + str(request.POST.get('recipient'))):
                        os.makedirs('messages/' + str(
                            request.POST.get('recipient')))  # each user has a folder server-side that stores messages
                    file = open('messages/' + str(request.POST.get('recipient')) + '/'
                                + str(request.POST.get('subject')), 'a')  # file is named by the subject of the message
                    file.write(str(request.POST.get('body')))  # file contains body of message
                    log_activity(action='Message sent to ' + str(request.POST.get('recipient')), request=request)
                    return render(request, 'health/error_template.html', {'message': "Message sent successfully"})
                else:
                    return render(request, 'health/error_template.html',
                                  {'message': "A user with the provided email does not exist"})
            else:
                return render(request, 'health/error_template.html',
                              {'message': "There were errors in your message form: ", 'errors': form.errors})
        else:
            form = MessageForm()
            return render(request, 'health/message_form.html', {'form': form})
    else:
        return render_to_response('health/notFound.html')


def display_messages(request):
    """
    displays private message sent
    :param request: user input
    :return: private message
    """
    if request.user.is_authenticated():
        if os.path.exists('messages/' + str(request.user.username)):
            message_subject_list = os.listdir('messages/' + str(request.user.username))
            message_body_list = []
            for message in message_subject_list:
                file = open('messages/' + str(request.user.username) + '/' + message, 'r')
                message_body_list.append(file.read())
            return render(request, 'health/message_view.html',
                          {'message_subjects': message_subject_list, 'message_body_list': message_body_list})
        else:
            return render(request, 'health/error_template.html', {'message': "No messages yet!"})


def download_file(request, file_name):
    """
    Displays the file
    :param request: user input
    :param file_name: file
    :return:
    """
    if request.user.is_authenticated():
        if os.path.exists(settings.MEDIA_ROOT + str(file_name)):
            if Patient.objects.filter(username=request.user.username).exists():
                patient = get_object_or_404(Patient, username=request.user.username)
                if str(patient.medical_information) == file_name:
                    log_activity(action="Patient downloaded medical information file: " + str(file_name),
                                 request=request)
                    file = open(settings.MEDIA_ROOT + file_name, 'rb')
                    response = HttpResponse(file, content_type="force-download")
                    response['Content-Disposition'] = 'attachment; filename=%s' % str(patient.medical_information.name)
                    return response
                else:
                    for test in Test.objects.filter(patient=patient):
                        if file_name == test.results:
                            if test.is_released:
                                log_activity(action="Patient downloaded medical information file: " + str(file_name),
                                             request=request)
                                file = open(settings.MEDIA_ROOT + file_name, 'rb')
                                response = HttpResponse(file, content_type="force-download")
                                response['Content-Disposition'] = 'attachment; filename=%s' % str(
                                    test.results)
                                return response
                            else:
                                return render(request, 'health/error_template.html',
                                              {'message':"The requested test has not yet been released"})

                    log_activity(
                                action="Patient attempted to access medical information file: " + str(file_name),
                                request=request)
                    return render(request, "health/notFound.html")

            elif Nurse.objects.filter(username=request.user.username).exists():
                # TODO nurses should only be able to download patient info from working hospital
                nurse = Nurse.objects.get(id=request.user.id)
                patient = Patient.objects.get(medical_information=file_name)
                if patient.main_hospital.id == nurse.working_hospital.id or nurse.working_hospital.id == patient.current_hospital_id:
                    log_activity(action="Nurse downloaded medical information file: " + str(file_name), request=request)
                    file = open(settings.MEDIA_ROOT + file_name, 'rb')
                    response = HttpResponse(file, content_type="application/force-download")
                    response['Content-Disposition'] = 'attachment; filename=%s' % str(file_name)
                    return response
                else:
                    log_activity(
                        action="Nurse attempted to access medical information file outside of working hospital: " + str(file_name),
                        request=request)

            elif Doctor.objects.filter(username=request.user.username).exists():
                log_activity(action="Doctor downloaded medical information file: " + str(file_name), request=request)
                file = open(settings.MEDIA_ROOT + file_name, 'rb')
                response = HttpResponse(file, content_type="application/force-download")
                response['Content-Disposition'] = 'attachment; filename=%s' % str(file_name)
                return response
            else:  # if admin
                log_activity(action="Admin downloaded medical information file: " + str(file_name), request=request)
                file = open(settings.MEDIA_ROOT + file_name, 'rb')
                response = HttpResponse(file, content_type="application/force-download")
                response['Content-Disposition'] = 'attachment; filename=%s' % str(file_name)
                return response
        else:
            return render(request, "health/notFound.html")
    else:
        return render(request, "health/notFound.html")


def make_new_prescription(request):
    if request.user.is_staff:
        if request.method == "POST":
            form = PrescriptionForm(request.POST)
            if form.is_valid():
                prescription = form.save(commit=False)
                if Prescription.objects.filter(prescription_name=prescription.prescription_name).exists():
                    return render(request, 'health/invalid_email.html')
                else:
                    prescription.save()
                    log_activity(action='Prescription created', request=request)
                    return render(request, 'health/calendar.html')
            else:
                return render(request, 'health/error_template.html',
                              {'message': "There were errors in your prescription creation form: ",
                               'errors': form.errors})
        else:
            form = PrescriptionForm()
            return render(request, 'health/register.html', {'form': form, 'title': "New Prescription",
                                                            'submit': "Create", 'cancel': "Cancel"})
    else:
        return render(request, 'health/notFound.html')


def add_prescription_to_patient(request):
    if Doctor.objects.filter(id=request.user.id).exists() or Nurse.objects.filter(id=request.user.id).exists():
        if request.method == "POST":
            form = AddPatientPrescriptionForm(request.POST)
            if form.is_valid():
                patient = get_object_or_404(Patient, id=request.POST.get('patient'))
                patient.prescriptions.add(Prescription.objects.get(id=request.POST.get('prescription')))
                patient.save()
                return render(request, 'health/error_template.html', {'message': "Prescription added successfully"})
            else:
                return render(request, 'health/error_template.html',
                              {'message': "There were errors in your prescription creation form: ",
                               'errors': form.errors})
        else:
            form = AddPatientPrescriptionForm()
            return render(request, 'health/register.html', {'form': form, 'title': "New Patient Prescription",
                                                            'submit': "Prescribe", 'cancel': "Cancel"})
    else:
        return render(request, 'health/notFound.html')


def patient_profile_view(request):
    if request.user.is_authenticated():
        if Patient.objects.filter(id=request.user.id).exists():
            patient = get_object_or_404(Patient, id=request.user.id)
            prescription_list = []
            for prescription in patient.prescriptions.all():
                prescription_list.append(prescription.prescription_name)
            return render(request, 'health/profile_view.html', {'patient': patient, 'prescriptions': prescription_list})
        else:
            return render(request, 'health/notFound.html')
    else:
        return render(request, 'health/notFound.html')


def admit_patient(request):
    if Doctor.objects.filter(id=request.user.pk).exists():
        if request.method == 'POST':
            form = DoctorAdmitPatientForm(data=request.POST)
            if form.is_valid():
                patient = get_object_or_404(Patient, id=request.POST.get('patient'))
                if patient.current_hospital_id == 0:
                    hospital = get_object_or_404(Hospital, id=request.POST.get('hospital'))
                    post_checked_hospital_id = request.POST.get('hospital')
                    patient.current_hospital_id = post_checked_hospital_id
                    patient.is_checked_in = True
                    patient.number_hospital_visits += 1
                    if patient.current_hospital_id != patient.main_hospital.id:
                        hospital.number_patients += 1
                    patient.temp_checked_in_time = timezone.now()
                    hospital.number_patient_visits += 1
                    patient.save()
                    hospital.save()
                    log_activity(action='Patient ' + str(
                        patient.id) + '(' + patient.get_full_name() + ')' + ' admitted into hospital ' + str(
                        hospital.id) + '(' + hospital.hospital_name + ') For the following reason: "' + request.POST.get(
                        'reason') + '"',
                                 request=request)
                    return render(request, 'health/patient_admitted.html')
                else:
                    return render(request, 'health/error_template.html', {'message': "Patient already admitted, discharge them first"})
            else:
                return render(request, 'health/error_template.html',
                              {'message': "There were errors in your form:", 'errors': form.errors})
        else:
            form = DoctorAdmitPatientForm()
            return render(request, 'health/admit_patient.html', {'form': form})

    elif Nurse.objects.filter(id=request.user.pk).exists():
        nurse = get_object_or_404(Nurse, id=request.user.pk)
        if request.method == 'POST':
            form = NurseAdmitPatientForm(data=request.POST)
            if form.is_valid():
                patient = get_object_or_404(Patient, id=request.POST.get('patient'))
                if patient.current_hospital_id == 0:
                    patient.current_hospital_id = nurse.working_hospital.id
                    patient.is_checked_in = True
                    patient.number_hospital_visits += 1
                    patient.temp_checked_in_time = timezone.now()
                    patient.save()
                    log_activity(action='Patient ' + str(
                        patient.id) + '(' + patient.get_full_name() + ')' + ' admitted into hospital ' + str(
                        nurse.working_hospital.id) + '(' + nurse.working_hospital.hospital_name + ') For the following reason: "' + request.POST.get('reason') + '"',
                                 request=request)
                    return render(request, 'health/patient_admitted.html')
                else:
                    return render(request, 'health/error_template.html', {'message': "Patient already admitted, discharge them first"})
            else:
                return render(request, 'health/error_template.html',
                              {'message': "There were errors in your form:", 'errors': form.errors})
        else:
            form = NurseAdmitPatientForm()
            return render(request, 'health/admit_patient.html', {'form': form})
    else:
        return render(request, "health/notFound.html")


def patient_discharge(request, patient_id):
    if Doctor.objects.filter(id=request.user.pk).exists():
        if Patient.objects.filter(id=patient_id).exists():
            patient = get_object_or_404(Patient, id=patient_id)
            patient.is_checked_in = False
            hospital = patient.main_hospital
            checked_in_hospital = Hospital.objects.get(id=patient.current_hospital_id)
            if patient.current_hospital_id != hospital.id:
                checked_in_hospital.number_patients -= 1
                checked_in_hospital.save()
            patient.current_hospital_id = 0
            patient.temp_check_out_time = timezone.now()
            patient.avg_hospital_visit_time = ((patient.number_hospital_visits - 1) * patient.avg_hospital_visit_time +
                                               (sdi(str(patient.temp_check_in_time)) -
                                                sdi(str(patient.temp_check_out_time)))) / patient.number_hospital_visits
            hospital.average_number_hospital_visits_per_patient = (hospital.average_number_hospital_visits_per_patient *
                                                                   hospital.number_patients +
                                                                   patient.number_hospital_visits) / hospital.number_patients
            patient.save()
            hospital.save()

            if not patient.is_checked_in:
                return render(request, 'health/patient_discharged.html')
            else:
                return render(request, 'health/error_template.html', {'message':"ERROR: Please contact your nearest administrator"})
        else:
            return render(request, 'health/error_template.html', {'message': "No such patient exists!"})
    else:
        return render(request, 'health/notFound.html')


def view_statistics(request, patient=None, hospital=None):
    if request.user.is_staff:
        if patient is None and hospital is None:
            if request.method == "POST":
                form = ViewStatisticsForm(request.POST)
                if form.is_valid():
                    hospital_id = request.POST.get('hospital')
                    patient_id = request.POST.get('patient')
                    prescription_id = request.POST.get('prescription')
                else:
                    return render(request, 'health/error_template.html',
                                  {'message': "There were errors in your log search form: ", 'errors': form.errors})
            else:
                form = ViewStatisticsForm()
                return render(request, 'health/log_search.html', {'form': form})
            if hospital_id == '' and patient_id == '':
                return render(request, 'health/error_template.html', {'message': "Please select either a hospital or a patient"})
            elif patient_id != '':
                patient = get_object_or_404(Patient, id=patient_id)
                avg_hospital_visit_time = patient.avg_hospital_visit_time
                number_hospital_visits = patient.number_hospital_visits
                return render(request, 'health/patient_stats.html', {'message': "Patient statistics for: " + patient.username,
                                                                    'avg_hospital_visit_time': avg_hospital_visit_time,
                                                                    'number_hospital_visits': number_hospital_visits})
            elif prescription_id != '':
                prescription = get_object_or_404(Prescription, id=prescription_id)
                times_prescribed = {'times prescribed':prescription.times_prescribed}
                return render(request, 'health/error_template.html', {'message': "Times prescribed for " +
                                                                      str(prescription.prescription_name),
                                                                      'errors': times_prescribed})
            elif hospital_id != '':
                hospital = get_object_or_404(Hospital, id=hospital_id)
                number_patients = hospital.number_patients
                number_patient_visits = hospital.number_patient_visits
                average_number_hospital_visits_per_patient = hospital.average_number_hospital_visits_per_patient
                average_patient_stay_time = hospital.average_patient_stay_time
                return render(request, 'health/hospital_stats.html', {'message':'Hospital stats for ' +
                                                                    str(hospital.hospital_name), 'number_patients': number_patients,
                                                                    'number_patient_visits': number_patient_visits,
                                                                    'average_number_hospital_visits_per_patient':
                                                                     average_number_hospital_visits_per_patient,
                                                                    'average_patient_stay_time': average_patient_stay_time})
       ## else:  can take parameters. maybe. not.


    else:
        return render(request, 'health/notFound.html')



def is_doc(request):
    for group in request.user.groups.all():
        if group.name == "Doctor":
            return True
    return False


def is_nurse(request):
    for group in request.user.groups.all():
        if group.name == "Nurse":
            return True
    return False


def is_patient(request):
    for group in request.user.groups.all():
        if group.name == "Patient":
            return True
    return False


