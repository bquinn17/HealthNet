from django.conf.urls import url, include

# This file is only for urls that are specific to this app.
# Technically since we only have one app, we don't really need anything in here
from django.contrib import admin
# Admin


urlpatterns = [
    url(r'^admin/', include(admin.site.urls)),
    # url(r'^$', views.patient_registration, name='post_list'),
    # url(r'^register', views.patient_registration, name='new_patient'),
    # url(r'^post/(?P<pk>\d+)/$', views.post_new, name='post_detail'),
    # url(r'^post/new/$', views.post_new, name='post_new'),
]
