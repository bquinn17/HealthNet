from django.contrib import admin
from health.models import *

admin.site.register(Patient)
admin.site.register(Appointment)
admin.site.register(Doctor)
admin.site.register(Nurse)
admin.site.register(Hospital)
admin.site.register(Prescription)
admin.site.register(Test)
admin.site.register(Reason)
